/* ============================================================
   ABINEL FESTO KILUFI — PORTFOLIO SCRIPT
   Slideshow + Smooth Scroll + Fade-in Animations
   ============================================================ */

// ============ SLIDESHOW ============
const slides = document.querySelectorAll('.slide');
const dots = document.querySelectorAll('.dot');
let currentSlide = 0;
let slideInterval;

function showSlide(index) {
  slides.forEach((slide, i) => {
    slide.classList.toggle('active', i === index);
    if (dots[i]) dots[i].classList.toggle('active', i === index);
  });
  currentSlide = index;
}

function nextSlide() {
  const next = (currentSlide + 1) % slides.length;
  showSlide(next);
}

function startSlideshow() {
  slideInterval = setInterval(nextSlide, 3500); // Badilisha kila sekunde 3.5
}

// Bofya dot kubadilisha slide
dots.forEach(dot => {
  dot.addEventListener('click', () => {
    clearInterval(slideInterval);
    showSlide(parseInt(dot.dataset.index));
    startSlideshow();
  });
});

// Anzisha slideshow kama picha zipo
if (slides.length > 0) {
  startSlideshow();
}

// ============ SMOOTH SCROLL ============
document.querySelectorAll('nav a, .hero-text a').forEach(link => {
  link.addEventListener('click', function (e) {
    const href = this.getAttribute('href');
    if (href && href.startsWith('#')) {
      e.preventDefault();
      const target = document.querySelector(href);
      if (target) {
        target.scrollIntoView({ behavior: 'smooth', block: 'start' });
      }
    }
  });
});

// ============ FADE-IN ANIMATION ON SCROLL ============
const observer = new IntersectionObserver(entries => {
  entries.forEach(entry => {
    if (entry.isIntersecting) {
      entry.target.style.opacity = 1;
      entry.target.style.transform = 'translateY(0)';
    }
  });
}, { threshold: 0.15 });

document.querySelectorAll('.card, .project, .section h2').forEach(el => {
  el.style.opacity = 0;
  el.style.transform = 'translateY(40px)';
  el.style.transition = '0.7s ease';
  observer.observe(el);
});

console.log('✅ Portfolio ya Abinel ipo tayari!');